﻿export class User {
    id: number;
    number: string;
    order: string;
    firstName: string;
    lastName: string;
    authdata?: string;
}