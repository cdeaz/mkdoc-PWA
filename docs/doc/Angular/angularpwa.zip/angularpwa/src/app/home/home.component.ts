﻿import { Component } from '@angular/core';
import { first } from 'rxjs/operators';
import { salesorder } from '../home/home.service';

import { User } from '@app/_models';
import { UserService } from '@app/_services';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent {
    salesorders : salesorder[] = [];
    OrderId : string;
    loading = false;
    users: User[];

    constructor(private userService: UserService) { }

    ngOnInit() {
        this.salesorders = [
            {
                "Id": 1,
                "OrderId" : "100010237",
                "status": "Closed",
                "date": "26 févr. 2010",
                "ship": "0001007260",
                "purchase": "17990",
                "soldto": "0001007260",
                "shipdate": "10 févr. 2010",
                "material": "56508 URILINE 100 AGAR SLIDES",
                "quantities": "Display quantities",
                "tracknum": ""
            },
            {
                "Id": 2,
                "OrderId" : "100011111",
                "status": "Closed",
                "date": "26 févr. 2010",
                "ship": "0001007260",
                "purchase": "17990",
                "soldto": "0001007260",
                "shipdate": "10 févr. 2010",
                "material": "56508 URILINE 100 AGAR SLIDES",
                "quantities": "Display quantities",
                "tracknum": ""
            }, 
            {
                "Id": 3,
                "OrderId" : "100020202",
                "status": "Closed",
                "date": "26 févr. 2010",
                "ship": "0001007260",
                "purchase": "17990",
                "soldto": "0001007260",
                "shipdate": "10 févr. 2010",
                "material": "56508 URILINE 100 AGAR SLIDES",
                "quantities": "Display quantities",
                "tracknum": ""
            },
            {
                "Id": 4,
                "OrderId" : "100010800",
                "status": "Closed",
                "date": "26 févr. 2010",
                "ship": "0001007260",
                "purchase": "17990",
                "soldto": "0001007260",
                "shipdate": "10 févr. 2010",
                "material": "56508 URILINE 100 AGAR SLIDES",
                "quantities": "Display quantities",
                "tracknum": ""
            },
            {
                "Id": 5,
                "OrderId" : "100099999",
                "status": "Closed",
                "date": "26 févr. 2010",
                "ship": "0001007260",
                "purchase": "17990",
                "soldto": "0001007260",
                "shipdate": "10 févr. 2010",
                "material": "56508 URILINE 100 AGAR SLIDES",
                "quantities": "Display quantities",
                "tracknum": ""
            },
            {
                "Id": 5,
                "OrderId" : "100022222",
                "status": "Closed",
                "date": "26 févr. 2010",
                "ship": "0001007260",
                "purchase": "17990",
                "soldto": "0001007260",
                "shipdate": "10 févr. 2010",
                "material": "56508 URILINE 100 AGAR SLIDES",
                "quantities": "Display quantities",
                "tracknum": ""
            }
            
        ];
        this.loading = true;
        this.userService.getAll().pipe(first()).subscribe(users => {
            this.loading = false;
            this.users = users;

        });
    }

    Search(){
        if(this.OrderId !="")  {
            this.salesorders = this.salesorders.filter(res=>{
                return res.OrderId.toLocaleLowerCase().match(this.OrderId.toLocaleLowerCase());
            });
        }else if (this.OrderId == ""){
          this.ngOnInit();  
        }
       
    }
}