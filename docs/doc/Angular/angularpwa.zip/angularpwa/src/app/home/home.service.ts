export class salesorder
{
    Id : number;
    OrderId : string;
    status: string;
    date: string;
    ship: string;
    purchase: string;
    soldto: string;
    shipdate: string;
    material: string;
    quantities: string;
    tracknum: string;

}